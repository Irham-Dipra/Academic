package io;

public class TxtReportWriter extends ReportWriter {
    @Override
    protected ReportFormatter createFormatter() {
        return new TxtFormatter();
    }
}