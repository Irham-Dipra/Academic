package io;

import model.Expense;
import service.Summarizer;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.List;

public abstract class ReportFormatter {
    private final DateTimeFormatter dateFormatter;
    private final DateTimeFormatter monthFormatter;

    public ReportFormatter() {
        this.dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        this.monthFormatter = DateTimeFormatter.ofPattern("yyyy-MM");
    }

    protected String formatDate(LocalDate date) {
        return date.format(dateFormatter);
    }

    protected String formatMonth(YearMonth month) {
        return month.format(monthFormatter);
    }

    protected String formatAmount(double amount) {
        return String.format("%.2f", amount);
    }

    public abstract String getHeader();
    public abstract String getMonthlySummary(Summarizer summarizer);
    public abstract String getCategoryBreakdown(Summarizer summarizer);
    public abstract String getGrandTotal(Summarizer summarizer);
    public abstract String getRecentEntries(List<Expense> expenses);

    public String getFooter() {
        return "";
    }

}
