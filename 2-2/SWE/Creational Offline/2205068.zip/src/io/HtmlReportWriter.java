package io;

public class HtmlReportWriter extends ReportWriter {
    @Override
    protected ReportFormatter createFormatter() {
        return new HtmlFormatter();
    }
}

