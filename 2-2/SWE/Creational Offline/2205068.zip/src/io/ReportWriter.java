package io;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import model.Expense;
import service.ExpenseRepository;
import service.Summarizer;

public abstract class ReportWriter {

    public final void writeReport(String filePath, ExpenseRepository repository) throws IOException {
        List<Expense> allExpenses = repository.findAll();
        Summarizer summarizer = new Summarizer(allExpenses);

        ReportFormatter formatter = createFormatter();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(formatter.getHeader());
            writer.write(formatter.getMonthlySummary(summarizer));
            writer.write(formatter.getCategoryBreakdown(summarizer));
            writer.write(formatter.getGrandTotal(summarizer));
            writer.write(formatter.getRecentEntries(allExpenses));
            writer.write(formatter.getFooter());
        }

        System.out.println("Report written to: " + filePath);

    }
    protected abstract ReportFormatter createFormatter();
    
}
