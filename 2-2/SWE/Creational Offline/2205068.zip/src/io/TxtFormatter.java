package io;

import model.Expense;
import service.Summarizer;
import java.time.YearMonth;
import java.util.List;
import java.util.Map;
import util.TextUtils;

public class TxtFormatter extends ReportFormatter {
    @Override
    public String getHeader() {
        StringBuilder sb = new StringBuilder();
        sb.append("=====================================\n");
        sb.append("       BUDGETBUDDY EXPENSE REPORT    \n");
        sb.append("=====================================\n\n");
        return sb.toString();
    }

    @Override
    public String getMonthlySummary(Summarizer summarizer) {
        StringBuilder sb = new StringBuilder();
        sb.append("MONTHLY SUMMARY\n");
        sb.append(TextUtils.separator(60) + "\n");

        Map<YearMonth, Double> monthlyTotals = summarizer.monthlyTotals();
        for (Map.Entry<YearMonth, Double> entry : monthlyTotals.entrySet()) {
            String monthStr = formatMonth(entry.getKey());
            String amountStr = formatAmount(entry.getValue());
            sb.append(String.format("%-10s : %12s\n", monthStr, amountStr));
        }
        sb.append("\n");
        return sb.toString();
    }

    @Override
    public String getCategoryBreakdown(Summarizer summarizer) {
        StringBuilder sb = new StringBuilder();
        sb.append("CATEGORY BREAKDOWN (All Time)\n");
        sb.append(TextUtils.separator(60) + "\n");

        Map<String, Double> categoryTotals = summarizer.categoryTotals(null);
        double maxAmount = categoryTotals.values().stream()
                .max(Double::compareTo)
                .orElse(1.0);

        for (Map.Entry<String, Double> entry : categoryTotals.entrySet()) {
            String category = entry.getKey();
            double amount = entry.getValue();
            String amountStr = formatAmount(amount);
            String bar = TextUtils.createBar(amount, maxAmount, 30);
            sb.append(String.format("%-15s %12s  %s\n", category, amountStr, bar));
        }
        sb.append("\n");
        return sb.toString();
    }

    @Override
    public String getGrandTotal(Summarizer summarizer) {
        StringBuilder sb = new StringBuilder();
        sb.append(TextUtils.separator(60) + "\n");
        sb.append(String.format("GRAND TOTAL: %s\n", formatAmount(summarizer.grandTotal())));
        sb.append(TextUtils.separator(60) + "\n");
        return sb.toString();
    }


    @Override
    public String getRecentEntries(List<Expense> expenses) {
        StringBuilder sb = new StringBuilder();
        sb.append("\nRECENT ENTRIES (Last 10)\n");
        sb.append(TextUtils.separator(60) + "\n");

        int count = 0;
        for (int i = expenses.size() - 1; i >= 0 && count < 10; i--, count++) {
            Expense exp = expenses.get(i);
            String dateStr = formatDate(exp.getDate());
            sb.append(String.format("%s  %-12s %10s  %s\n",
                    dateStr,
                    exp.getCategory(),
                    formatAmount(exp.getAmount()),
                    exp.getNotes()));
        }
        return sb.toString();


    }
    
}
