import java.util.Scanner;

public class CancelledState extends State {
    

    public CancelledState(Course course)
    {
        super(course);
        status = CourseStatus.CANCELLED;
    }

    public boolean isVisibleToStudent()
    {
        return false;
    }
    
    public boolean tryEnroll(Student s)
    {
        System.out.println("Cannot enroll; course is CANCELLED: " + course.code);
        return false;
    }

    public boolean addToWaitList(Student s)
    {
        System.out.println("Cannot waitlist; course not accepting waitlist: " + course.code);
        return false;
    }

    public void handlePromoteFromWaitlist()
    {
        return;
    }

    public void handlePostCapacityChange()
    {
        System.out.println("Course is CANCELLED; capacity change has no effect.");
        return;
    }

    public void changeState(CourseStatus newStatus)
    {
        switch(newStatus){
            case DRAFT:
                course.changeState(new DraftState(course));
                System.out.println(course.code + " transitioned CANCELLED -> DRAFT (reinstating course)");
                break;
            default:
                System.out.println("Invalid: CANCELLED can only transition to DRAFT for " + course.code);
        }
    }

    public void handleSetStatusAdminInteractive(CourseStatus newStatus, Scanner scanner)
    {
        setStatusAdmin(newStatus);
        return;
    }
}