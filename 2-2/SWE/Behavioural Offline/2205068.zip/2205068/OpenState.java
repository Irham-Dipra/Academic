import java.util.Scanner;
public class OpenState extends State {

    public OpenState(Course course)
    {
        super(course);
        status = CourseStatus.OPEN;
    }

    public boolean isVisibleToStudent()
    {
        return true;
    }

    public boolean tryEnroll(Student s)
    {
        if (course.getEnrolledCount() < course.getCapacity()) {
            course.addToEnrolledList(s);
            course.getRegistrarSystem().enrollStudentInCourseDirect(s, course);
            System.out.println("Enrolled: " + s.name + " in " + course.code);
            if (course.getEnrolledCount() >= course.getCapacity()) {
                course.changeState(new FullState(course));
                System.out.println(course.code + " is now FULL.");
            }
            return true;
        } else {
            // capacity reached while OPEN -> FULL and suggest waitlist
            course.changeState(new FullState(course));
            System.out.println(course.code + " reached capacity; status set to FULL. Try waitlisting.");
            return false;
        }
    }

    public boolean addToWaitList(Student s)
    {
        System.out.println("Course is OPEN; try enrolling instead: " + course.code);
        return false;
    }

    void handlePromoteFromWaitlist()
    {
        promote();
        if( course.getEnrolledList().size() >= course.getCapacity()) {
            course.changeState(new FullState(course));
        }
    }

    public void handlePostCapacityChange()
    {
        if (course.getEnrolledList().size() < course.getCapacity()) {
                course.changeState(new OpenState(course));
                System.out.println(course.code + " status changed to OPEN (capacity allows enrollment).");
        } else if (course.getEnrolledList().size() == course.getCapacity()) {
            course.changeState(new FullState(course));
            System.out.println(course.code + " status changed to FULL (at capacity).");
        } else {
            // more enrolled than capacity: keep FULL, admin must resolve
            course.changeState(new FullState(course));
            System.out.println(course.code + " over capacity; remains FULL.");
        }
    }

    public void changeState(CourseStatus newStatus)
    {
        switch (newStatus){
            case CLOSED:
                course.changeState(new ClosedState(course));
                System.out.println(course.code + " transitioned OPEN -> CLOSED");
                break;
            case DRAFT:
                course.changeState(new DraftState(course));
                System.out.println(course.code + " transitioned OPEN -> DRAFT");
                break;
            case CANCELLED:
                course.cancelCourse();
                break;
            default:
                System.out.println("Invalid transition from OPEN to " + newStatus);
        }
    }

    public void handleSetStatusAdminInteractive(CourseStatus newStatus, Scanner scanner)
    {
        setStatusAdmin(newStatus);
        return;
    }
}
