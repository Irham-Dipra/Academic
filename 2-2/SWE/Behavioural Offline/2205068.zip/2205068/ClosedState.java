import java.util.Scanner;

public class ClosedState extends State {
    

    public ClosedState(Course course)
    {
        super(course);
        status = CourseStatus.CLOSED;
    }

    public boolean isVisibleToStudent()
    {
        return true;
    }

    public boolean tryEnroll(Student s)
    {
        System.out.println("Cannot enroll; course is CLOSED: " + course.code);
        return false;
    }

    public boolean addToWaitList(Student s)
    {
        System.out.println("Cannot waitlist; course not accepting waitlist: " + course.code);
        return false;
    }

    void handlePromoteFromWaitlist()
    {
        promote();
        if (course.getEnrolledList().size() >= course.getCapacity()) {
            course.changeState(new FullState(course));
        }
    }

    public void handlePostCapacityChange()
    {
        if (course.getEnrolledList().size() < course.getCapacity()) {
                course.changeState(new OpenState(course));
                System.out.println(course.code + " status changed to OPEN (capacity allows enrollment).");
        } else if (course.getEnrolledList().size() == course.getCapacity()) {
            course.changeState(new FullState(course));
            System.out.println(course.code + " status changed to FULL (at capacity).");
        } else {
            // more enrolled than capacity: keep FULL, admin must resolve
            course.changeState(new FullState(course));
            System.out.println(course.code + " over capacity; remains FULL.");
        }
    }

    public void changeState(CourseStatus newStatus)
    {
        switch (newStatus){
            case OPEN:
                course.changeState(new OpenState(course));
                System.out.println(course.code + " transitioned CLOSED -> OPEN");
                break;
            case DRAFT:
                course.changeState(new DraftState(course));
                System.out.println(course.code + " transitioned CLOSED -> DRAFT");
                break;
            case CANCELLED:
                course.cancelCourse();
                break;
            default:
                System.out.println("Invalid transition from CLOSED to " + newStatus);
        }
    }

    public void handleSetStatusAdminInteractive(CourseStatus newStatus, Scanner scanner)
    {
        setStatusAdmin(newStatus);
        return;
    }
}
