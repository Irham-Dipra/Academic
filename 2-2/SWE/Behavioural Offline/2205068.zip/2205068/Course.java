import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Course extends Component {
    public final String code;
    public final String title;
    private int capacity;
    // public CourseStatus status;
    private final List<Student> enrolled = new ArrayList<>();
    private final LinkedList<Student> waitlist = new LinkedList<>();
    private State state;

    public Course(RegistrarSystem r, String code, String title, int capacity, CourseStatus status) {
        super(r);
        this.code = code;
        this.title = title;
        this.capacity = Math.max(0, capacity);
        state = switch (status) {
            case OPEN      -> new OpenState(this);
            case FULL      -> new FullState(this);
            case CLOSED    -> new ClosedState(this);
            case DRAFT     -> new DraftState(this);
            case CANCELLED -> new CancelledState(this);
        };
    }

    public boolean isVisibleToStudents() {
        return state.isVisibleToStudent();
    }

    public boolean tryEnroll(Student s) {
        if (s == null) return false;
        return state.tryEnroll(s);
    }

    public boolean addToWaitlist(Student s) {
        if (s == null) return false;
        return state.addToWaitList(s);
    }

    public boolean dropStudent(Student s) {
        if (s == null) return false;
        return state.dropStudent(s);
    }

    public void setCapacity(int newCapacity) {
        state.setCapacity(newCapacity);
    }

    public void setStatusAdmin(CourseStatus newStatus) {
        state.setStatusAdmin(newStatus);
    }

    // Interactive version for admin with Scanner (prompts for capacity increase)
    public void setStatusAdminInteractive(CourseStatus newStatus, Scanner scanner) {
        state.setStatusAdminInteractive(newStatus, scanner);
    }

    public void cancelCourse() {
        changeState(new CancelledState(this));
        // clear enrolled and waitlist, update students
        for (Student s : new ArrayList<>(enrolled)) {
            registrarSystem.removeStudentFromCourseDirect(s, this);
        }
        for (Student s : new ArrayList<>(waitlist)) {
            registrarSystem.removeStudentFromCourseDirect(s, this);
        }
        enrolled.clear();
        waitlist.clear();
        System.out.println(code + " has been CANCELLED. All students dropped and waitlist cleared.");
    }

    public void closeWithRandomWaitlistSelection(int targetCapacity) {
        changeState(new ClosedState(this));
        System.out.println(code + " transitioned FULL -> CLOSED");
        
        // If there are waitlisted students and space available, promote random students
        if (!waitlist.isEmpty()) {
            int availableSlots = targetCapacity - enrolled.size();
            if (availableSlots > 0) {
                Random random = new Random();
                List<Student> waitlistCopy = new ArrayList<>(waitlist);
                int promotionCount = Math.min(availableSlots, waitlistCopy.size());
                
                System.out.println("Randomly selecting " + promotionCount + " student(s) from waitlist:");
                for (int i = 0; i < promotionCount; i++) {
                    int randomIndex = random.nextInt(waitlistCopy.size());
                    Student promoted = waitlistCopy.remove(randomIndex);
                    waitlist.remove(promoted);
                    enrolled.add(promoted); 
                    registrarSystem.enrollStudentInCourseDirect(promoted, this);
                    System.out.println("  Randomly selected: " + promoted.name + " for " + code);
                }
            }
        }
    }

    public void printRoster() {
        System.out.println("Roster for " + code + " - " + title + " (" + getStatus() + ", cap=" + capacity + "):");
        if (enrolled.isEmpty()) {
            System.out.println("  [no enrolled]");
        } else {
            for (Student s : enrolled) {
                System.out.println("  " + s.id + " - " + s.name);
            }
        }
    }

    public void printWaitlist() {
        System.out.println("Waitlist for " + code + ":");
        if (waitlist.isEmpty()) {
            System.out.println("  [no waitlisted]");
        } else {
            for (Student s : waitlist) {
                System.out.println("  " + s.id + " - " + s.name);
            }
        }
    }

    public void addToEnrolledList(Student s)
    {
        enrolled.add(s);
    }

    public void addToWaitlistList(Student s)
    {
        waitlist.add(s);
    }

    public void changeState(State newState)
    {
        this.state = newState;
    }

    // Exposed getters for UI/reporting
    public int getCapacity() { return capacity; }
    public int getEnrolledCount() { return enrolled.size(); }
    public int getWaitlistCount() { return waitlist.size(); }
    public RegistrarSystem getRegistrarSystem() { return registrarSystem; }
    public List<Student> getEnrolledList() { return enrolled; }
    public LinkedList<Student> getWaitlist() { return waitlist; }
    public State getState() { return state; }
    public CourseStatus getStatus() { return state.getStatus(); }

    public void setCapacityDirect(int capacity) {
        this.capacity = capacity;
    }
}
