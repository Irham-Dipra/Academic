import java.util.Scanner;

abstract class State {
    
    protected Course course;
    public CourseStatus status;

    public State(Course course)
    {
        this.course = course;
    }

    abstract boolean isVisibleToStudent();
    abstract boolean tryEnroll(Student s);
    abstract boolean addToWaitList(Student s);
    abstract void handlePromoteFromWaitlist();
    abstract void handlePostCapacityChange();
    abstract void changeState(CourseStatus newStatus);
    abstract void handleSetStatusAdminInteractive(CourseStatus newStatus, Scanner scanner);
    public boolean dropStudent(Student s)
    {
        boolean changed = false;
        if (course.getEnrolledList().contains(s)) {
            course.getEnrolledList().remove(s);
            course.getRegistrarSystem().removeStudentFromCourseDirect(s, course);
            System.out.println("Dropped from enrolled: " + s.name + " from " + course.code);
            changed = true;
            handlePromoteFromWaitlist();
        } else if (course.getWaitlist().contains(s)) {
            course.getWaitlist().remove(s);
            course.getRegistrarSystem().removeStudentFromCourseDirect(s, course);
            System.out.println("Removed from waitlist: " + s.name + " for " + course.code);
            changed = true;
        } else {
            System.out.println(s.name + " is neither enrolled nor waitlisted for " + course.code);
        }
        return changed;
    }
    public void setCapacity(int newCapacity) {
        if (newCapacity < 0) newCapacity = 0;
        System.out.println("Setting capacity of " + course.code + " to " + newCapacity);
        course.setCapacityDirect(newCapacity);
        handlePostCapacityChange();
    }
    
    public CourseStatus getStatus() {
        return status;
    }

    public void setStatusAdmin(CourseStatus newStatus)
    {
        if (newStatus == null) return;
        if (newStatus == status) {
            System.out.println("No change: " + course.code + " already " + status);
            return;
        }
        changeState(newStatus);
    }

    public void setStatusAdminInteractive(CourseStatus newStatus, Scanner scanner)
    {
        if (newStatus == null) return;
        if (newStatus == status) {
            System.out.println("No change: " + course.code + " already " + status);
            return;
        }
        handleSetStatusAdminInteractive(newStatus, scanner);
    }

    public void promote()
    {
        if (course.getEnrolledList().size() < course.getCapacity() && !course.getWaitlist().isEmpty()) {
            Student promoted = course.getWaitlist().poll();
            if (promoted != null) {
                course.getEnrolledList().add(promoted);
                course.getRegistrarSystem().enrollStudentInCourseDirect(promoted, course);
                System.out.println("Promoted from waitlist: " + promoted.name + " into " + course.code);
            }
        }
    }

}
