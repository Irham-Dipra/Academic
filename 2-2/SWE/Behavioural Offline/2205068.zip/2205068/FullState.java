import java.util.Scanner;

public class FullState extends State {
    

    public FullState(Course course)
    {
        super(course);
        status = CourseStatus.FULL;
    }

    public boolean isVisibleToStudent()
    {
        return true;
    }

    public boolean tryEnroll(Student s)
    {
        System.out.println("Cannot enroll; course is FULL. You may waitlist: " + course.code);
        return false;
    }

    public boolean addToWaitList(Student s)
    {
        if (course.getEnrolledList().contains(s)) {
            System.out.println("Already enrolled; no need to waitlist: " + s.name + " for " + course.code);
            return false;
        }
        if (course.getWaitlist().contains(s)) {
            System.out.println("Already waitlisted: " + s.name + " for " + course.code);
            return false;
        }
        course.getWaitlist().add(s);
        course.getRegistrarSystem().waitlistStudentInCourseDirect(s, course);
        System.out.println("Waitlisted: " + s.name + " for " + course.code);
        return true;
    }


    public void handlePromoteFromWaitlist()
    {
        promote();
        if (course.getEnrolledList().size() < course.getCapacity()) {
            course.changeState(new OpenState(course));
            System.out.println(course.code + " status changed to OPEN due to available capacity.");
        }
        else {
            course.changeState(new FullState(course));
        }
    }

    public void handlePostCapacityChange()
    {
        if (course.getEnrolledList().size() < course.getCapacity()) {
                course.changeState(new OpenState(course));
                System.out.println(course.code + " status changed to OPEN (capacity allows enrollment).");
        } else if (course.getEnrolledList().size() == course.getCapacity()) {
            course.changeState(new FullState(course));
            System.out.println(course.code + " status changed to FULL (at capacity).");
        } else {
            // more enrolled than capacity: keep FULL, admin must resolve
            course.changeState(new FullState(course));
            System.out.println(course.code + " over capacity; remains FULL.");
        }
    }

    public void changeState(CourseStatus newStatus)
    {
        switch(newStatus){
            case CLOSED:
                course.closeWithRandomWaitlistSelection(course.getCapacity());
                break;
            case CANCELLED:
                course.cancelCourse();
                break;
            default:
                System.out.println("Invalid transition from FULL to " + newStatus + " (FULL->OPEN is automatic on drop)");
        }
    }

    public void handleSetStatusAdminInteractive(CourseStatus newStatus, Scanner scanner)
    {
        if(newStatus == CourseStatus.CLOSED) {
            if(!course.getWaitlist().isEmpty()) {
                System.out.println(course.code + " has " + course.getWaitlist().size() + " student(s) on waitlist.");
                System.out.print("Do you want to increase capacity before closing? (Enter new capacity, or 0 to not increase): ");
                try {
                    int newCapacity = Integer.parseInt(scanner.nextLine().trim());
                    if (newCapacity > 0) {
                        if (newCapacity > course.getCapacity()) {
                            course.setCapacityDirect(newCapacity);
                            System.out.println("Capacity increased to " + newCapacity);
                            course.closeWithRandomWaitlistSelection(newCapacity);
                        } else {
                            System.out.println("New capacity must be greater than current capacity (" + course.getCapacity() + "). No change.");
                            course.closeWithRandomWaitlistSelection(course.getCapacity());
                        }
                    } else {
                        System.out.println("No capacity increase.");
                        course.closeWithRandomWaitlistSelection(course.getCapacity());
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Closing without capacity increase.");
                    course.closeWithRandomWaitlistSelection(course.getCapacity());
                }
            } else {
                // No waitlist, just close
                course.closeWithRandomWaitlistSelection(course.getCapacity());
            }
            return;
        }
    }
}
