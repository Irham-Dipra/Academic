abstract class Component{
    
    protected RegistrarSystem registrarSystem;

    public Component(RegistrarSystem r){
        this.registrarSystem = r;
    }
}