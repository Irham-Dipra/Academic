import java.util.Scanner;
public class DraftState extends State {
    

    public DraftState(Course course)
    {
        super(course);
        status = CourseStatus.DRAFT;
    }

    public boolean isVisibleToStudent()
    {
        return false;
    }

    public boolean tryEnroll(Student s)
    {
        System.out.println("Cannot enroll; course is DRAFT (not visible): " + course.code);
        return false;
    }

    public boolean addToWaitList(Student s)
    {
        System.out.println("Cannot waitlist; course not accepting waitlist: " + course.code);
        return false;
    }

    public void handlePromoteFromWaitlist()
    {
        return;
    }

    public void handlePostCapacityChange()
    {
        if (course.getEnrolledList().size() == course.getCapacity()) {
            course.changeState(new FullState(course));
            System.out.println(course.code + " status changed to FULL (at capacity).");
        } else {
            // more enrolled than capacity: keep FULL, admin must resolve
            course.changeState(new FullState(course));
            System.out.println(course.code + " over capacity; remains FULL.");
        }
    }

    public void changeState(CourseStatus newStatus)
    {
        switch(newStatus){
            case OPEN:
                course.changeState(new OpenState(course));
                System.out.println(course.code + " transitioned DRAFT -> OPEN");
                break;
            case CLOSED:
                course.changeState(new ClosedState(course));
                System.out.println(course.code + " transitioned DRAFT -> CLOSED");
                break;
            case CANCELLED:
                course.cancelCourse();
                break;
            default:
                System.out.println("Invalid transition from DRAFT to " + newStatus);
        }
    }

    public void handleSetStatusAdminInteractive(CourseStatus newStatus, Scanner scanner)
    {
        setStatusAdmin(newStatus);
        return;
    }
}
