import java.util.*;

public class RegistrarSystem{
    private final Map<String, Student> students = new HashMap<>();
    private final Map<String, Course> courses = new HashMap<>();

    public void addStudent(Student s) {
        if (s != null) students.put(s.id, s);
    }

    public void addCourse(Course c) {
        if (c != null) courses.put(c.code, c);
    }

    public Student getStudent(String id) {
        return students.get(id);
    }

    public Course getCourse(String code) {
        return courses.get(code);
    }

    public Collection<Student> getAllStudents() {
        return students.values();
    }

    public Collection<Course> getAllCourses() {
        return courses.values();
    }

    public void enrollStudentInCourse(Student student, Course course) {
        if (course == null) return;
        if (!course.isVisibleToStudents()) {
            System.out.println("Course " + course.code + " is not available for student enrollment.");
            return;
        }
        List<Course> enrolledCourses = new ArrayList<>(student.getEnrolledCourses()); 
        if (enrolledCourses.contains(course)) {
            System.out.println(student.name + " is already enrolled in " + course.code);
            return;
        }
        course.tryEnroll(student);
    }

    public void enrollStudentInCourseDirect(Student student, Course course)
    {
        student.addEnrolledCourseDirect(course);
    }

    public void waitlistStudentInCourse(Student student, Course course)
    {
        if (course == null) return;
        if (!course.isVisibleToStudents()) {
            System.out.println("Course " + course.code + " is not available.");
            return;
        }
        List <Course> waitlistedCourses = new ArrayList<>(student.getWaitlistedCourses());
        if (waitlistedCourses.contains(course)) {
            System.out.println(student.name + " is already waitlisted for " + course.code);
            return;
        }
        List<Course> enrolledCourses = new ArrayList<>(student.getEnrolledCourses()); 
        if (enrolledCourses.contains(course)) {
            System.out.println(student.name + " is already enrolled in " + course.code + "; cannot waitlist.");
            return;
        }
        course.addToWaitlist(student);
    }

    public void waitlistStudentInCourseDirect(Student student, Course course)
    {
        student.addWaitlistCourseDirect(course);
    }

    public void dropStudentFromCourse(Student student, Course course)
    {
        course.dropStudent(student);
    }

    public void removeStudentFromCourseDirect(Student student, Course course)
    {
        student.removeCourseDirect(course);
    }

    // public void getCoursesOverview(){
    //     for (Map.Entry<String, Course> entry : courses.entrySet()) {
    //         Course course = entry.getValue();
    //         course.printRoster();
    //         course.printWaitlist();
    //     }

    // }

    // public void getStudentsOverview(){
    //     for (Map.Entry<String, Student> entry : students.entrySet()) {
    //         Student student = entry.getValue();
    //         student.printSchedule();
    //     }
    // }
}
